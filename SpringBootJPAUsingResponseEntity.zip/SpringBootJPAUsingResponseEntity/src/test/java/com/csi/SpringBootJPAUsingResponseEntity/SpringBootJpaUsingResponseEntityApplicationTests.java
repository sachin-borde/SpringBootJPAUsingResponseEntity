package com.csi.SpringBootJPAUsingResponseEntity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaUsingResponseEntityApplicationTests {

	@Test
	void contextLoads() {
	}

}
