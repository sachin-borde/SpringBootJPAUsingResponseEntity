package com.csi.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.csi.model.Customer;
import com.csi.repository.CustomerRepository;

@Component
public class CustomerDao {

	@Autowired
	CustomerRepository customerrepository;

	public List<Customer> getAllData() {
		return (List<Customer>) customerrepository.findAll();
	}

	public void saveData(Customer customer) {
		customerrepository.save(customer);
	}

	public void updateData(int custId, Customer customer) {
		customerrepository.save(customer);
	}

	public void deleteDataById(int custId) {
		customerrepository.deleteById(custId);
	}

	public Optional<Customer> getDataById(int custId) {
		return customerrepository.findById(custId);
	}

	public void saveAllData(List<Customer> customers) {
		customerrepository.saveAll(customers);
	}

	public void deleteAllData() {
		customerrepository.deleteAll();
	}

}
