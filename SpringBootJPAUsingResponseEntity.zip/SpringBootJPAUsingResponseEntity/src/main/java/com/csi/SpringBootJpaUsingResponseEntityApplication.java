package com.csi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaUsingResponseEntityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaUsingResponseEntityApplication.class, args);
	}

}
