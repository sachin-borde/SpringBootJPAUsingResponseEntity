package com.csi.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.csi.dao.CustomerDao;
import com.csi.model.Customer;

@RestController
@RequestMapping("/api")
public class CustomerController {

	@Autowired
	CustomerDao customerdao;

	@GetMapping("/getdata")
	public ResponseEntity<List<Customer>> getAllData() {
		return ResponseEntity.ok(customerdao.getAllData());
	}

	@PostMapping("/savedata")
	public ResponseEntity<String> saveData(@RequestBody Customer customer) {
		customerdao.saveData(customer);
		return ResponseEntity.ok("Data Saved");
	}

	@PutMapping("/updatedata/{custId}")
	public ResponseEntity<String> updateData(@RequestBody Customer customer, @PathVariable("custId") int custId) {
		customerdao.updateData(custId, customer);
		return ResponseEntity.ok("Data Updated");
	}

	@DeleteMapping("/deletedatabyid/{custId}")
	public ResponseEntity<String> deleteDataById(@PathVariable("custId") int custId) {
		customerdao.deleteDataById(custId);
		return ResponseEntity.ok("Data Delete");
	}

	@GetMapping("/getdatabyid/{custId}")
	public ResponseEntity<Optional<Customer>> getDataById(@PathVariable("custId") int custId) {
		return ResponseEntity.ok(customerdao.getDataById(custId));
	}

	@PostMapping("/savealldata")
	public ResponseEntity<String> saveAllData(@RequestBody List<Customer> customers) {
		customerdao.saveAllData(customers);
		return ResponseEntity.ok("All data saved");
	}

	@DeleteMapping("/deleteall")
	public ResponseEntity<String> deleteAllData() {
		customerdao.deleteAllData();
		return ResponseEntity.ok("empty");
	}
}
